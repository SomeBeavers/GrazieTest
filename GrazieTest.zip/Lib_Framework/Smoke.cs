﻿using System;

namespace Lib_Framework
{
    public class SmokeWithTypoHere
    {
        private void Test()
        {
            var string_var = @"some string";

            Console.WriteLine(string_var);
        }
    }
}