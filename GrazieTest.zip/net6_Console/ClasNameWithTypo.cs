﻿namespace net6_Console;


public class ClasNameWithTypo
{
    // ClasNameWithTypo
    // коммент на русском.

    private void Test() {
        string someName = "";
        Console.WriteLine(someName);
    }
}