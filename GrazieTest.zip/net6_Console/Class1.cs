﻿namespace net6_Console;

public class Class1
{
    private void Test()
    {
        var s = "";
    }
}