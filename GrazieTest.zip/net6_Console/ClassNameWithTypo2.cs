﻿namespace net6_Console;

public class ClasNameWithTypoaaaaaaaa
{
    
}