﻿// see https://aka.ms/new-console-template for more infomation
// see hello, World.  You're totally awesome.
Console.WriteLine("Hello, World! You're awesome");
